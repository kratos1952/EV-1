import java.util.Scanner;

public class LecturaEntrada {

    private final Scanner scanner = new Scanner(System.in);

    public String leerTexto(String mensaje) {
        System.out.print(mensaje);
        return scanner.nextLine().trim();
    }

    public int leerEntero(String mensaje) {
        while (true) {
            try {
                return Integer.parseInt(leerTexto(mensaje));
            } catch (NumberFormatException e) {
                System.out.println("Entrada inválida: debes ingresar un número entero.");
            }
        }
    }

    public double leerDecimal(String mensaje, double minimo, double maximo) {
        while (true) {
            try {
                double valor = Double.parseDouble(leerTexto(mensaje));
                if (valor >= minimo && valor <= maximo) {
                    return valor;
                }
                System.out.println("El valor debe estar entre " + minimo + " y " + maximo + ".");
            } catch (NumberFormatException e) {
                System.out.println("Entrada inválida: debes ingresar un número (usa punto para decimales).");
            }
        }
    }
}