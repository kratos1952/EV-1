import java.util.List;
import java.util.Locale;

public class Main {

    public static void main(String[] args) {
        GestorTallerBicicletas gestor = new GestorTallerBicicletas();

        cargarDatosInstitucionales(gestor);
        demostracionInstitucional(gestor);
        ejecutarMenu(gestor);
    }

    private static void cargarDatosInstitucionales(GestorTallerBicicletas gestor) {
        BicicletaElectrica e01 = new BicicletaElectrica("BIC-E01", 2023, 22.5, 60, false);
        e01.activarGarantiaExtendida();
        BicicletaElectrica e02 = new BicicletaElectrica("BIC-E02", 2022, 24.0, 45, true);
        BicicletaMontanya m01 = new BicicletaMontanya("BIC-M01", 2021, 13.5, 2);
        BicicletaMontanya m02 = new BicicletaMontanya("BIC-M02", 2020, 12.0, 1);

        gestor.registrar(e01);
        gestor.registrar(e02);
        gestor.registrar(m01);
        gestor.registrar(m02);
    }

    private static void demostracionInstitucional(GestorTallerBicicletas gestor) {
        System.out.println("\n--- Búsqueda por código: BIC-E01 ---");
        mostrarResultados(gestor.buscarPorCodigo("BIC-E01"));

        System.out.println("\n--- Listado de bicicletas registradas ---");
        gestor.listarBicicletas();
    }

    private static void ejecutarMenu(GestorTallerBicicletas gestor) {
        LecturaEntrada lectura = new LecturaEntrada();
        int opcion;

        do {
            System.out.println("\n===== TALLER DE BICICLETAS =====");
            System.out.println("1. Listar todas las bicicletas");
            System.out.println("2. Buscar por código");
            System.out.println("3. Simular costo de mantención con descuento");
            System.out.println("4. Salir");
            opcion = lectura.leerEntero("Seleccione una opción: ");

            switch (opcion) {
                case 1:
                    gestor.listarBicicletas();
                    break;
                case 2:
                    String codigo = lectura.leerTexto("Código a buscar: ");
                    mostrarResultados(gestor.buscarPorCodigo(codigo));
                    break;
                case 3:
                    simularDescuento(gestor, lectura);
                    break;
                case 4:
                    System.out.println("Hasta luego.");
                    break;
                default:
                    System.out.println("Opción no válida. Elija un número del 1 al 4.");
            }
        } while (opcion != 4);
    }

    private static void simularDescuento(GestorTallerBicicletas gestor, LecturaEntrada lectura) {
        String codigo = lectura.leerTexto("Código de la bicicleta: ");
        List<Bicicleta> resultados = gestor.buscarPorCodigo(codigo);

        if (resultados.isEmpty()) {
            System.out.println("No se encontró ninguna bicicleta con ese código.");
            return;
        }

        double descuento = lectura.leerDecimal("Porcentaje de descuento (0 a 100): ", 0, 100);

        for (Bicicleta b : resultados) {
            System.out.println(b + " | Costo normal: " + formatearCosto(b.calcularCostoMantencion())
                    + " | Costo con " + descuento + "% de descuento: "
                    + formatearCosto(b.calcularCostoMantencion(descuento)));
        }
    }

    private static void mostrarResultados(List<Bicicleta> resultados) {
        if (resultados.isEmpty()) {
            System.out.println("No se encontraron bicicletas con ese código.");
            return;
        }
        for (Bicicleta b : resultados) {
            System.out.println(b.obtenerDetalle());
            System.out.println("Costo de mantención: " + formatearCosto(b.calcularCostoMantencion()));
        }
    }

    private static String formatearCosto(double costo) {
        return String.format(new Locale("es", "CL"), "$%,.0f", costo);
    }
}