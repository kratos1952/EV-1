public class BicicletaMontanya extends Bicicleta {

    //prueba para commmit

    private int cantidadSuspensiones;

    public BicicletaMontanya(String codigoBicicleta, int anioFabricacion,
                             double pesoKg, int cantidadSuspensiones) {
        super(codigoBicicleta, anioFabricacion, pesoKg);
        this.cantidadSuspensiones = cantidadSuspensiones;
    }

    public int getCantidadSuspensiones() {
        return cantidadSuspensiones;
    }

    public void setCantidadSuspensiones(int cantidadSuspensiones) {
        this.cantidadSuspensiones = cantidadSuspensiones;
    }

    @Override
    public double calcularCostoMantencion() {
        double costo = 30000;

        if (cantidadSuspensiones > 1) {
            costo = costo * 1.15;
        }

        return costo;
    }
}