import java.util.ArrayList;
import java.util.List;

public class GestorTallerBicicletas {

    private List<Bicicleta> bicicletas = new ArrayList<>();

    public void registrar(Bicicleta bicicleta) {
        if (bicicleta == null) {
            System.out.println("No se puede registrar una bicicleta nula.");
            return;
        }
        bicicletas.add(bicicleta);
        System.out.println("Bicicleta registrada correctamente: " + bicicleta);
    }

    public List<Bicicleta> buscarPorCodigo(String criterio) {
        List<Bicicleta> coincidencias = new ArrayList<>();
        if (criterio == null) {
            return coincidencias;
        }
        for (Bicicleta b : bicicletas) {
            if (b.getCodigoBicicleta().equalsIgnoreCase(criterio.trim())) {
                coincidencias.add(b);
            }
        }
        return coincidencias;
    }

    public void listarBicicletas() {
        if (bicicletas.isEmpty()) {
            System.out.println("No hay bicicletas registradas.");
            return;
        }
        for (Bicicleta b : bicicletas) {
            System.out.println(b + " | Costo de mantención: " + b.calcularCostoMantencion());
        }
    }
}