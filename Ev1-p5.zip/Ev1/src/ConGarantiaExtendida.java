public interface ConGarantiaExtendida {
    //prueba para commmit
    boolean tieneGarantiaExtendidaActiva();

    void activarGarantiaExtendida();
}