import java.util.List;
import java.util.Locale;

public class Main {

    public static void main(String[] args) {
        GestorTallerBicicletas gestor = new GestorTallerBicicletas();

        BicicletaElectrica e01 = new BicicletaElectrica("BIC-E01", 2023, 22.5, 60, false);
        e01.activarGarantiaExtendida();
        BicicletaElectrica e02 = new BicicletaElectrica("BIC-E02", 2022, 24.0, 45, true);
        BicicletaMontanya m01 = new BicicletaMontanya("BIC-M01", 2021, 13.5, 2);
        BicicletaMontanya m02 = new BicicletaMontanya("BIC-M02", 2020, 12.0, 1);

        gestor.registrar(e01);
        gestor.registrar(e02);
        gestor.registrar(m01);
        gestor.registrar(m02);

        System.out.println("\n--- Búsqueda por código: BIC-E01 ---");
        List<Bicicleta> resultados = gestor.buscarPorCodigo("BIC-E01");
        for (Bicicleta b : resultados) {
            System.out.println(b.obtenerDetalle());
            System.out.println("Costo de mantención: " + formatearCosto(b.calcularCostoMantencion()));
        }

        System.out.println("\n--- Listado de bicicletas registradas ---");
        gestor.listarBicicletas();
    }

    private static String formatearCosto(double costo) {
        return String.format(new Locale("es", "CL"), "$%,.0f", costo);
    }
}