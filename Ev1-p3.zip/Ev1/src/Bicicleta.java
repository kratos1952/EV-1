public abstract class Bicicleta {
    //prueba para commmit
    private String codigoBicicleta;
    private int anioFabricacion;
    private double pesoKg;

    public Bicicleta(String codigoBicicleta, int anioFabricacion, double pesoKg) {
        setCodigoBicicleta(codigoBicicleta);
        setAnioFabricacion(anioFabricacion);
        setPesoKg(pesoKg);
    }

    public String getCodigoBicicleta() {
        return codigoBicicleta;
    }

    public void setCodigoBicicleta(String codigoBicicleta) {
        if (codigoBicicleta == null || codigoBicicleta.isEmpty()) {
            System.out.println("El código no puede ser nulo ni vacío");
            return;
        }
        this.codigoBicicleta = codigoBicicleta;
    }

    public int getAnioFabricacion() {
        return anioFabricacion;
    }

    public void setAnioFabricacion(int anioFabricacion) {
        if (anioFabricacion < 2000 || anioFabricacion > 2026) {
            System.out.println("El año debe estar entre 2000 y 2026");
            return;
        }
        this.anioFabricacion = anioFabricacion;
    }

    public double getPesoKg() {
        return pesoKg;
    }

    public void setPesoKg(double pesoKg) {
        if (pesoKg <= 0) {
            System.out.println("El peso debe ser mayor que cero");
            return;
        }
        this.pesoKg = pesoKg;
    }

    public abstract double calcularCostoMantencion();

    public double calcularCostoMantencion(double porcentajeDescuento) {
        if (porcentajeDescuento < 0 || porcentajeDescuento > 100) {
            System.out.println("El porcentaje debe estar entre 0 y 100");
            return calcularCostoMantencion();
        }
        return calcularCostoMantencion() * (1 - porcentajeDescuento / 100);
    }

    @Override
    public String toString() {
        return codigoBicicleta + " " + anioFabricacion;

        // En Java es necesario especificar qué tipo de dato se está utilizando.
        // Las clases permiten organizar los datos junto con los métodos que los utilizan.
        // En la programación procedural, los datos y las funciones suelen manejarse de forma más independiente.


    }
}