public class BicicletaElectrica extends Bicicleta {
    private double autonomiaKm;
    private boolean bateriaCertificada;

    public BicicletaElectrica(String codigoBicicleta, int anioFabricacion, double pesoKg,
                              double autonomiaKm, boolean bateriaCertificada) {
        super(codigoBicicleta, anioFabricacion, pesoKg);
        this.autonomiaKm = autonomiaKm;
        this.bateriaCertificada = bateriaCertificada;
    }

    public double getAutonomiaKm() {
        return autonomiaKm;
    }

    public void setAutonomiaKm(double autonomiaKm) {
        this.autonomiaKm = autonomiaKm;
    }

    public boolean isBateriaCertificada() {
        return bateriaCertificada;
    }

    public void setBateriaCertificada(boolean bateriaCertificada) {
        this.bateriaCertificada = bateriaCertificada;
    }

    @Override
    public double calcularCostoMantencion() {
        double costo = 45000;
        if (!bateriaCertificada) {
            costo = costo * 1.25;
        }
        return costo;
    }

    @Override
    public String toString() {
        return super.toString() + " " + autonomiaKm + " " + bateriaCertificada;
    }
}